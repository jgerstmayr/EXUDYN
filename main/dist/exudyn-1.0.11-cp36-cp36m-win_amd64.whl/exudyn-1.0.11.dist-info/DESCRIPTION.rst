EXUDYN
A flexible multibody dynamics systems simulation code with Python and C++
For license information see LICENSE.txt
For more information, installation and tutorials see docs/theDoc/theDoc.pdf

